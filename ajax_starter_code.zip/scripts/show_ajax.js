$(document).ready(function(){

    $.getJSON('data/tweet_reply.json', function(data){
        console.log(data);
    });

});
